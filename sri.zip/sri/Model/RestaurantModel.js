const mongoose = require ("mongoose");
const restaurantSchema = new mongoose.Schema({
    
    name:{
        type:String,
        require:[true,"Name is require"],
        trim:true,
        minimumLength:[10,"Minimum 10 characters require"],
i     },
    cloudinaryImageId:{
        type:String,
    },
    locality:{
        type:String,
    },
    areaName:{
        type:String, 
    },
    costForTwo:{
        type:String,
    },
    cuisines:{
        type:Array,
    },
    avgRating:{
        type:Number,
        default:4.5,
        min:[1,"Less than 1 is not allowed"],
        max:[5,"More than 5 is not allowed"],
    },
    parentId:{
        type:String,
    },
    avgRatingString:{
        type:String,
    },
    totalRatingString:{
        type:String,
    },
    netClosedTime:{
        type:String,
    },
    opened:{
        type:Boolean,
        default:true,
    }

    

});
const Restaurant=mongoose.model("Restaurant",restaurantSchema);
module.exports=Restaurant;
