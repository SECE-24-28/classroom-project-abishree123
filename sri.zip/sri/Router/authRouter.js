const express = require("express");
const authRouter = express.Router();

const authController = require("../controller/authControllers");

authRouter.route("/login").post(authController.login);
authRouter.route("/signup").post(authController.signup);
authRouter.route("/getAllUsers").get(authController.allUsers);

module.exports = authRouter;
