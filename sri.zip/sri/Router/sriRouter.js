const express=require("express");
const authController=require("../controller/authControllers");
const sriController =require("../Controller/sriController","utf-8");



const sriRouter=express.Router();
sriRouter.route("/").get(sriController.getAll).post(sriController.rest);
sriRouter.route("/:id").get(sriController.get).put(sriController.getrest).delete(sriController.sris);
const authRouter=require("./authRouter");
module.exports=sriRouter;