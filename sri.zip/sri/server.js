const dotenv = require("dotenv");
const cors=require("cors");
dotenv.config({ path: "./config.env" });

const mongoose = require("mongoose");
const app = require("./index");
app.use(cors());

// DB CONNECT
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => console.log("DB connected successfully"))
  .catch((err) => console.log("DB Error:", err));

// SERVER START
const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
