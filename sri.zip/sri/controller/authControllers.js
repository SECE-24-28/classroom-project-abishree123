const jwt = require("jsonwebtoken");

const users = [
  {
    id: 1,
    name: "ABi",
    email: "abi@gmail.com",
    password: "12344578",
    confirmPassword: "12344578",
    role: "user",
  },
  {
    id: 2,
    name: "Abc",
    email: "abc@gmail.com",
    password: "1hiiii",
    confirmPassword: "1hiiii",
    role: "admin",
  },
];

// JWT TOKEN
const signToken = (id) => {
  return jwt.sign(
    { id },
    process.env.JWT_SECRETKEY,
    {
      expiresIn: process.env.JWT_EXPIRES,
    }
  );
};

// GET ALL USERS
exports.allUsers = (req, res) => {
  res.status(200).json({
    users,
  });
};

// LOGIN
exports.login = (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({
      status: "Fail",
      msg: "Email and password should not be empty",
    });
  }

  const user = users.find(
    (u) => u.email === email && u.password === password
  );

  if (!user) {
    return res.status(404).json({
      status: "Fail",
      msg: "Invalid email or password",
    });
  }

  const token = signToken(user.id);

  res.status(200).json({
    status: "Success",
    token,
    data: {
      email: user.email,
      name: user.name,
      role: user.role,
    },
  });
};

// SIGNUP
exports.signup = (req, res) => {
  const { name, email, password, role } = req.body;

  const existingUser = users.find((u) => u.email === email);
  if (existingUser) {
    return res.status(400).json({
      status: "fail",
      msg: "user already exists",
    });
  }

  const newUser = {
    id: users.length + 1,
    name,
    email,
    password,
    role: role || "user",
  };

  users.push(newUser);

  const token = signToken(newUser.id);

  res.status(201).json({
    status: "success",
    token,
    newUser,
  });
};
