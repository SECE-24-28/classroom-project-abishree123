const fs=require("fs");
const jsonData=JSON.parse(fs.readFileSync("./sri.json","utf-8"));


exports. getAll= (req, res) => {
    res.status(200).json({
      status: "successful",
      length: jsonData.length,
      timeOfHit:req.requestTimeOfHit,
      msg:req.message,
      data: {
        sri: jsonData
      }
    });
  };
  exports. get=(req, res) => {
  let id = Number(req.params.id);
  let sri = jsonData.find(el => el.id === id);
  if (!sri) {
    return res.status(200).json({
      status: "unsuccessful",
      message: "Sri with that id is not found"
    });
  }
  
  res.status(200).json({
    status: "successful",
    data: {
      sri
    }
  });
}




exports.rest=(req, res)=>{
    console.log(req.body);
    const Id = jsonData.length;
    const sri=Object.assign({id:Id},req.body);
    jsonData.push(sri);
    fs.writeFile("./sri.json",JSON.stringify(jsonData),err=>{
        if(err){
        res.status(400).json({
            status:"Failed to Write",
        });
    }
    res.status(200).json({
        status:"successful",
        data:{
            sri,
        },
    });
});
};

exports.getrest=(req, res)=>{
    const resId=Number(req.params.id);
    const sri=jsonData.find(el=>el.id===resId);
    if(!sri){
        return res.status(200).json({
            status:"unsuccessful",
            message:"Sri with that id is not found",
        });
    }
     Object.assign(sri, req.body);
    res.status(200).json({
        status:"successful",
        data:{
            sri,
        },
        message:"sri with that id is found",
    });

};

exports.sris= (req, res) => {
        let id = Number(req.params.id);
      
        let sri = jsonData.find(el => el.id === id);
        if (!sri) {
          return res.status(200).json({
            status: "unsuccessful",
            message: "Sri with that id is not found"
          });
        }
      

        jsonData.sris = jsonData.filter(el => el.id !== id);
      
        res.status(200).json({
          status: "successful",
          message: "sri deleted successfully"
        });
      };