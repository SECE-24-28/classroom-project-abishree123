const express = require("express");
const app = express();

app.use(express.json());


const sriRouter = require("./Router/sriRouter");
const authRouter = require("./Router/authRouter");

app.use((req, res, next) => {
  const now = new Date();
  req.requestTimeOfHit = now.toLocaleString();
  next();
});

app.use((req, res, next) => {
  req.message = "hi";
  next();
});

app.use("/api/v3/sri", sriRouter);
app.use("/api/v1/auth", authRouter);

module.exports = app;
